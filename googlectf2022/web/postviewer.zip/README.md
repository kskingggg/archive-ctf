Additional information about the challenge:

  * `/bot` endpoint is only used to send requests to the XSS bot, no vulnerabilities are intended to exist on that endpoint.

  * the XSS bot is forked from https://github.com/google/kctf/blob/v1/dist/challenge-templates/xss-bot/challenge/bot.js in a non-headless mode. 
It is supposed to imitate a real user as closely as possible and there are no intended vulnerabilities in the implementation. 

Good luck & have fun!
