#!/bin/bash

while [ 1 ]; do
    sleep 5m
    /tmp/haproxy/reload.sh
done

